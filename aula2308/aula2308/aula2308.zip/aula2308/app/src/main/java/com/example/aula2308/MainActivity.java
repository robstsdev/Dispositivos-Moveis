package com.example.aula2308;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Criando os Objetos da Tela
    private CheckBox chkNatacao, chkFutebol, chkBasquete;
    private Button btnMostrarDados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Associando o Java com o Layout (Classe R)
        chkNatacao = findViewById(R.id.chkNatacao);
        chkFutebol = findViewById(R.id.chkFutebol);
        chkBasquete = findViewById(R.id.chkBasquete);
        btnMostrarDados = findViewById(R.id.btnMostrarDados);
    }
    public void mostrar(View view){
        String nat=null, fut=null, bas=null;
        if(chkNatacao.isChecked())
            nat = "Natação";
        if(chkFutebol.isChecked())
            fut = "Futebol";
        if(chkBasquete.isChecked())
            bas = "Basquete";

        // caixa de mensagem - igual ao JOptionPane
        Toast.makeText(MainActivity.this, nat+" - "+fut+" - "+bas, Toast.LENGTH_LONG).show();

    }
}